package in.ac.charusat.studentmgmtsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMgmtSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentMgmtSystemApplication.class, args);
    }

}
